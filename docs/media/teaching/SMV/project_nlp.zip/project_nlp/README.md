Intro to NLP project
--------------------

1. Allez dans le dossier du projet dans une fenetre Terminal
2. Créer un environnement dédié avec:

```python -m venv .venv```

3. Active l'environnement:
```source .venv/bin/activate```

4. Installer les dépendances avec:
``` pip install -r requirements.txt```

5. Ouvrir le notebook dans vscode / cursor et choisir le kernel local .venv

Happy coding